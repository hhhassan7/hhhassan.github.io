hhhassan7.github.io
======================

Github repo for Hassan's Website

## How to create one for yourself
1. Fork the repo
2. Rename the repo as your-user-name.github.io
3. Check at http://your-user-name.github.io
4. Make changes as you want!

## How to run and make changes locally
Simply go to your cloned directory and if you have

1. NodeJS ```server```
2. Python 2.7x ```python -m SimpleHTTPServer```
3. Python 3.x ```python -m http.server```

#### Don't forget to star the repo if you like it ;)
